import React from 'react';
import { Outlet } from 'react-router-dom';

function ArticlesLayouts() {
    return (
        <div>
            <h1>ArticlesLayouts</h1>





            <Outlet/>
        </div>
    );
}

export default ArticlesLayouts;